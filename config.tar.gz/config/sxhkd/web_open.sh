#!/bin/bash
firefox https://mxlinux.org/manuals/ https://eirenicon.org/knowledge-base/ https://antixlinux.com
#xdg-open 
