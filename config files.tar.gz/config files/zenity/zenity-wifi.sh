#!/bin/bash

nm-connection-editor
