# Keybinding Index
<hr/>

**Keybinding Help Index** ~ Super + F1

**Shared (Common) Keybindings** ~ Super + F2

**Binary Space Partitioning WM (bspwm)** ~ Super + F3

**HerbstLuftWM (hlwm)** ~ Super + F4

**xfce with zentile** ~ Super + F5

**Kitty Terminal Keybindings** ~ Super + F6

**Active Tasks List** ~ Super + F12
