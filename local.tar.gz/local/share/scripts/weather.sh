#!/bin/bash

sakura -e "curl wttr.in/39.38749845,-104.752330324"
