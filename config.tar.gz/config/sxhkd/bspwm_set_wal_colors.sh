#!/usr/bin/env bash
if [[ -f ~/.cache/wal/colors.sh ]]; then
	# shellcheck disable=SC1090
	source ~/.cache/wal/colors.sh

	# shellcheck disable=SC2154
	bspc config presel_feedback_color "$color1"
	bspc config normal_border_color "$color1"
	# shellcheck disable=SC2154
	bspc config active_border_color "$color2"
	# shellcheck disable=SC2154
	bspc config focused_border_color "$color15"
fi
