<span style="color:red">
# xfce with zentile![xfcelogo](https://wiki.manjaro.org/images/4/43/XFCE-logo.png)
(this is for a non-standard xfce setup)
<hr/>

## Additional Help Resources

See the [xfce web site](http://xfce.org/).

Also visit the [zentile web site](https://github.com/blrsn/zentile).

<hr/>
## Workspace Keybindings

**Tile current workspace **~ Ctrl + Shift + t

**Untile current workspace** ~ Ctrl + Shift + u

**Cycle through layouts** ~ Ctrl + Shift + s

**Go to next window** ~ Ctrl + Shift + n

**Go to previous window** ~ Ctrl + Shift + p

**Increase size of master windows** ~ Ctrl + ]

**Decrease size of master windows** ~ Ctrl + [

**Increment number of master windows** ~ Ctrl + Shift + i

**Decrement number of master windows** ~ Ctrl + Shift + d

<hr/>
## Other xfce keybindings

**Appfinder** ~ Alt + F3

**xfce4 display settings --minimal** ~ Super + P

**Desktop Menu** ~ Ctrl + Escape 
</span>
