# Kitty Terminal Keybindings


<hr/>

**Open Kitty terminal** ~ Ctrl + Shift + <enter>

**Change Kitty layout** ~ Ctrl + Shift + l

**Get Kitty help** ~ Ctrl + Shift + <esc>

**New window** ~ Ctrl + Shift + <enter>

**New OS window** ~ Ctrl + Shift + n

**Close window** ~ Ctrl + Shift + w

**Next window** ~ Ctrl + Shift + ]

**Previous window** ~ Ctrl + Shift + [

**Move window forward** ~ Ctrl + Shift + f

**Move window backward** ~ Ctrl + Shift + b

**Move window to top** ~ Ctrl + Shift + `

**Move neighboring_window left** ~ Ctrl + Left 

**Move move_window right** ~ Shift + Left 

**Move neighboring_window down** ~ Ctrl + Down

**Move move_window up** ~ Shift + up

**Focus specific window** ~ "Ctrl + Shift + 1, 
Ctrl + Shift + 2 ... Ctrl + Shift + 0"

**Scroll line up** ~ Ctrl + Shift + up

**Scroll line down** ~ Ctrl + Shift + down

**Scroll page up** ~ Ctrl + Shift + page_up

**Scroll page down** ~ Ctrl + Shift + page_down

**Scroll to top** ~ Ctrl + Shift + home

**Scroll to bottom** ~ Ctrl + Shift + end

**Copy to clipboard** ~ Ctrl + c

**Paste from clipboard** ~ Ctrl + v

**Paste from selection** ~ Ctrl + Shift + s

**Increase font size** ~ Ctrl + Shift + equal

**Decrease font size** ~ Ctrl + Shift + minus

**Restore font size** ~ Ctrl + Shift + backspace

**Toggle fullscreen** ~ Ctrl + Shift + F11

**Toggle maximized** ~ Ctrl + Shift + F10

**Input unicode character** ~ Ctrl + Shift + u

**Click URL using the keyboard** ~ Ctrl + Shift + e

**Reset the terminal** ~ Ctrl + Shift + delete

**Pass current selection to program** ~ Ctrl + Shift + o

**Edit Kitty config file** ~ Ctrl + Shift + F2

**Open a Kitty shell** ~ Ctrl + Shift + escape

**Increase background opacity** ~ Ctrl + Shift + a>m

**Decrease background opacity** ~ Ctrl + Shift + a>l

**Full background opacity** ~ Ctrl + Shift + a>1

**Reset background opacity** ~ Ctrl + Shift + a>d

**New tab** ~ Ctrl + Shift + t

**Close tab** ~ Ctrl + Shift + q

**Next tab** ~ Ctrl + Shift + right

**Previous tab** ~ Ctrl + Shift + Left

**Next layout** ~ Ctrl + Shift + l

**Move tab forward** ~ Ctrl + Shift + .

**Move tab backward** ~"Ctrl + Shift + ,"

**Set tab title** ~ Ctrl + Shift + alt + t
