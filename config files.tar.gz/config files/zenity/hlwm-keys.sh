#!/bin/bash

pandoc -t plain "$Home/.local/share/scripts/hlwm-keys.md" | less
