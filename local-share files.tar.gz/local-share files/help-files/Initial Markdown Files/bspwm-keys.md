
# bspwm (Binary Space Partitioning Window Manager)
![bspwmlogo](https://i1.wp.com/eirenicon.org/wp-content/uploads/2019/06/bspwm.png?w=187&ssl=1)
<hr/>

## Additional Help Resources

**See the following:**

[bspwm Github web site](https://github.com/baskerville/bspwm/). 

[arch linux -bspwm](https://wiki.archlinux.org/index.php/Bspwm/).

[bspwm for dummies](https://github.com/windelicato/dotfiles/wiki/bspwm-for-dummies/).

<hr/>

## Default bspwn Keybindings 
> <u><b>Note:</b></u> bspwm defines the Windows key as **Super key**.

**Hide polybar** ~ super + h

**Expand window by moving a side outward** ~ super + alt + {h,j,k,l}

**Shrink window by moving a side inward** ~ super + alt + shift + {h,j,k,l}

**Move a floating window **~ super + {Left,Down,Up,Right}

**Change workspace focus** ~ alt + {1,2,3,4,5,6,7,8,9,0}
	
**Close & kill** ~ super + {_,shift + }w

**Toggle tiled & monocle** ~ super + m

**Send newest marked node to newest preselected node** ~ super + y

**Swap the current node and biggest node** ~ super + g

**Modify window state (tiled,pseudo_tiled,floating,fullscreen)** ~ super + {t,shift + t,s,f}

**Set node flags (marked,locked,sticky,private)** ~ super + ctrl + {m,x,y,z}

**Alter node focus (west,south,north,east)** ~ super + {_,shift + }{h,j,k,l}

**Focus a node for a given path jump (parent,brother,first,second)** ~ super + {p,b,comma,period}

**Alter node focus (next/previous) on current desktop** ~ super + {_,shift + }c

**Alter node focus (next/previous) on current monitor** ~ super + bracket{left,right}

**Focus on last node/desktop** ~ super + {grave,Tab}

**Focus on an older or newer node using history** ~ super + {o,i}

**Focus or send to a desktop** ~ super + {_,shift + }{1-9,0}

**Preselect a direction** ~ super + ctrl + {h,j,k,l}

**Preselect a ratio** ~ super + ctrl + {1-9}

**Cancel preselected node focus** ~ super + ctrl + space

**Cancel preselected desktop focus** ~ super + ctrl + shift + space

**Expand window by moving a side** ~ super + alt + {h,j,k,l}

**Contract window by moving a side** ~ super + alt + shift + {h,j,k,l}

**Swap active window with the largest on the current desktop** ~ super + shift + b

**Mouse pointer raises window focus** ~ button1
