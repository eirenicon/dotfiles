#### fancy
![fancy](https://53280.de/rofi/fancy.png)

#### flat-orange
![flat_orange](https://53280.de/rofi/flat_orange.png)

#### oxide
![oxide](https://53280.de/rofi/oxide.png)

#### solarized-darker
![solarized_darker](https://53280.de/rofi/solarized_darker.png)

#### sidetab
![sidetab](https://53280.de/rofi/sidetab.png)

#### material
![material](https://53280.de/rofi/material.png)

#### arc-red-dark
![arc-red-dark](https://53280.de/rofi/arc-red.png)

#### onedark
![onedark](https://53280.de/rofi/onedark.png)

#### ribbon
![ribbon](https://53280.de/rofi/ribbon.png)

#### rezlooks
![rezlooks](https://53280.de/rofi/rezlooks.png)
