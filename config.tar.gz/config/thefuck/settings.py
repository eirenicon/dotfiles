# The Fuck settings file
#
# The rules are defined as in the example bellow:
#
# rules = ['cd_parent', 'git_push', 'python_command', 'sudo']
#
# The default values are as follows. Uncomment and change to fit your needs.
# See https://github.com/nvbn/thefuck#settings for more information.
#

# wait_command = 3
# slow_commands = ['lein', 'react-native', 'gradle', './gradlew', 'vagrant']
# history_limit = None
# no_colors = False
# alter_history = True
# num_close_matches = 3
# rules = [<const: All rules enabled>]
# priority = {}
# exclude_rules = []
# env = {'LC_ALL': 'C', 'LANG': 'C', 'GIT_TRACE': '1'}
# instant_mode = False
# repeat = False
# debug = False
# require_confirmation = True
# wait_slow_command = 15
