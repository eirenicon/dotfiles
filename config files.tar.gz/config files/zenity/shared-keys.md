# Application & System 
**(Shared Keybindings)**
<hr/>
## Applications

**All Active Tasks** ~ super + F12

**calibre** ~ alt + c

**chromium** ~ super + alt + c

**eMail- Thunderbird** ~ alt + m
	
**firefox** ~ alt + w

**geany** ~ alt + g

**kitty Keybindings** ~ super + F6 

**kitty update** ~ alt + k

**LibreOffice** ~ alt + o

**mocp player** ~ alt + q

**nnn- File Manager** ~ alt + n

**Thunar File Manager** ~ alt + t

**VirtualBox** ~ alt + v
	
**zim wiki** ~ alt + z
<hr/>

## System Functions

**Hide polybar** ~ super + h

**Logout** ~ ctrl + alt + backspace

**Power Down** ~ ctrl + alt + k

**Reboot** ~ ctrl + alt + Delete

**Trackpad (Toggle)** ~ alt + p

**screenshot** ~ Print (PrtScr)

**Software Install (Synaptic)** ~ alt + s


	
